﻿using System.Reflection;
using System.Runtime.InteropServices;

[assembly: AssemblyTitle("Example-02 Application")]
[assembly: AssemblyDescription("Example Application #2")]
[assembly: AssemblyProduct("Example-02")]

[assembly: ComVisible(false)]
[assembly: Guid("5884e3b7-9015-471d-ab1b-5441143996cb")]
