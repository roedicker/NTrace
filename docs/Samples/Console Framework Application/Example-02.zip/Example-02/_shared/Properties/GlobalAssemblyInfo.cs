using System.Reflection;

[assembly: AssemblyConfiguration("retail")]
[assembly: AssemblyCompany("Mark Rödicker")]
[assembly: AssemblyCopyright("Copyright © 2020 Mark Rödicker")]
[assembly: AssemblyTrademark("")]
[assembly: AssemblyCulture("")]

[assembly: AssemblyVersion("1.0.0.0")]
