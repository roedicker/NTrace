﻿using System.Reflection;
using System.Runtime.InteropServices;

[assembly: AssemblyTitle("Example-02.Common")]
[assembly: AssemblyDescription("Example Application Common Library #2")]
[assembly: AssemblyProduct("Example-02.Common")]

[assembly: ComVisible(false)]
[assembly: Guid("c44e53d1-383a-4626-9e2f-d3724b7eabec")]
