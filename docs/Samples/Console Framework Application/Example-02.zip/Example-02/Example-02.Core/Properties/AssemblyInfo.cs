﻿using System.Reflection;
using System.Runtime.InteropServices;

[assembly: AssemblyTitle("Example-02.Core")]
[assembly: AssemblyDescription("Example Core Library #2")]
[assembly: AssemblyProduct("Example-02.Core")]

[assembly: ComVisible(false)]
[assembly: Guid("ea36df10-be4c-40e5-8ac3-d42508a7381b")]
